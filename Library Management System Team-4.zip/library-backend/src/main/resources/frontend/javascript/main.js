  // Display username
        const storedUsername = localStorage.getItem('username') || 'Student';
        document.getElementById('welcome-message').textContent = `Hello, ${storedUsername}`;

        // Logout functionality
        document.getElementById('logout-button').addEventListener('click', () => {
            alert("Logging out...");
            localStorage.removeItem('userToken');
            localStorage.removeItem('username');
            // ✅ Redirect to login page (make sure login.html exists)
            window.location.href = "login.html";
        });

        // Fetch books and borrowed books when needed
        async function fetchBooks() {
            try {
                const response = await fetch("http://localhost:8080/api/books");
                const books = await response.json();
                renderBooks(books);
            } catch (error) {
                console.error("Error fetching books:", error);
            }
        }

        function renderBooks(books) {
            const tbody = document.querySelector("#booksTable tbody");
            if (!tbody) return; // prevents errors if table doesn't exist
            tbody.innerHTML = "";
            books.forEach(book => {
                const row = `
                    <tr>
                        <td>${book.id}</td>
                        <td>${book.title}</td>
                        <td>${book.author}</td>
                        <td>${book.available ? "Yes" : "No"}</td>
                        <td><button onclick="borrowBook('${book.id}')" ${!book.available ? "disabled" : ""}>Borrow</button></td>
                    </tr>`;
                tbody.innerHTML += row;
            });
        }

        async function borrowBook(id) {
            try {
                const response = await fetch(`http://localhost:8080/api/books/borrow/${id}`, { method: "PUT" });
                if (response.ok) {
                    alert("Book borrowed successfully!");
                    fetchBooks();
                    loadBorrowedBooks();
                } else {
                    const data = await response.json();
                    alert(data.message || "Failed to borrow book.");
                }
            } catch (error) {
                console.error("Error borrowing book:", error);
                alert("Could not reach server to borrow book.");
            }
        }

        async function loadBorrowedBooks() {
            try {
                const response = await fetch("http://localhost:8080/api/books/borrowed");
                const books = await response.json();
                const list = document.getElementById("borrowedBooks");
                if (!list) return; // prevents error if element missing
                list.innerHTML = "";
                books.forEach(b => {
                    list.innerHTML += `<li>${b.title}</li>`;
                });
            } catch (error) {
                console.error("Error loading borrowed books:", error);
            }
        }

        function searchBooks() {
            const input = document.getElementById("search");
            if (!input) return;
            let value = input.value.toLowerCase();
            let rows = document.querySelectorAll("#booksTable tbody tr");
            rows.forEach(row => {
                row.style.display = row.innerText.toLowerCase().includes(value) ? "" : "none";
            });
        }

        document.addEventListener('DOMContentLoaded', () => {
            fetchBooks();
            loadBorrowedBooks();
        });