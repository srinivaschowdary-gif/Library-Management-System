// ✅ Correct API endpoint for your Spring Boot backend
const API_URL = "http://localhost:8080/api/books";


// --- Sidebar Navigation ---
function navigateTo(page) {
    if (page === 'managebooks') window.location.href = 'managebook.html';
    else if (page === 'manageusers') window.location.href = 'ManageUser.html';
    else if (page === 'transactions') window.location.href = 'transaction.html';
}

function logout() {
    alert("Logging out...");
    window.location.href = "login.html";
}

// --- Load Books from Backend ---
async function loadBooks() {
    try {
        const res = await fetch(API_URL);
        const books = await res.json();
        const tbody = document.querySelector("#bookTable tbody");
        tbody.innerHTML = "";

        books.forEach((b, i) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${i + 1}</td>
                <td>${b.title}</td>
                <td>${b.author}</td>
                <td>${b.copies}</td>
                <td>
                    <button class="edit" onclick="editBook('${b.id}', '${b.title}', '${b.author}', ${b.copies})">Edit</button>
                    <button class="delete" onclick="deleteBook('${b.id}')">Delete</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error("Error loading books:", error);
        alert("Failed to load books from server.");
    }
}

// --- Add or Edit Book ---
function showAddForm() {
    document.getElementById("formTitle").innerText = "Add Book";
    document.getElementById("bookId").value = "";
    document.getElementById("title").value = "";
    document.getElementById("author").value = "";
    document.getElementById("copies").value = "";
    document.getElementById("bookForm").style.display = "flex";
}

function closeForm() {
    document.getElementById("bookForm").style.display = "none";
}

function editBook(id, title, author, copies) {
    document.getElementById("formTitle").innerText = "Edit Book";
    document.getElementById("bookId").value = id;
    document.getElementById("title").value = title;
    document.getElementById("author").value = author;
    document.getElementById("copies").value = copies;
    document.getElementById("bookForm").style.display = "flex";
}

// --- Save (POST or PUT) ---
async function saveBook(e) {
    e.preventDefault();

    const id = document.getElementById("bookId").value;
    const book = {
        title: document.getElementById("title").value,
        author: document.getElementById("author").value,
        copies: parseInt(document.getElementById("copies").value)
    };

    const method = id ? "PUT" : "POST";
    const url = id ? `${API_URL}/${id}` : API_URL;

    try {
        const res = await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(book)
        });

        if (res.ok) {
            closeForm();
            loadBooks();
        } else {
            alert("Failed to save book. Server responded with status " + res.status);
        }
    } catch (error) {
        console.error("Error saving book:", error);
        alert("Could not reach server to save book.");
    }
}

// --- Delete Book ---
async function deleteBook(id) {
    if (!confirm("Delete this book?")) return;
    try {
        const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
        if (res.ok) {
            loadBooks();
        } else {
            alert("Failed to delete book.");
        }
    } catch (error) {
        console.error("Error deleting book:", error);
        alert("Could not reach server to delete book.");
    }
}

// Load books when page opens
window.onload = loadBooks;
