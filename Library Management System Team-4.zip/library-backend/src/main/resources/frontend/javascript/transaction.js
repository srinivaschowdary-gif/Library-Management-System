// 🛑 UPDATED API URL FOR LIBRARIAN MANAGEMENT 🛑
const API = "http://localhost:8080/api/management/transactions";

// --- Navigation Functions for Sidebar ---
function navigateTo(page) {
    if (page === 'managebooks') window.location.href = 'managebook.html';
    else if (page === 'manageusers') window.location.href = 'ManageUser.html';
    else if (page === 'transactions') window.location.href = 'transaction.html';
}

function logout() {
    alert("Logging out...");
    window.location.href = "login.html"; 
}
// ----------------------------------------

async function fetchTransactions() {
    try {
        // Uses the new API constant
        const res = await fetch(API);
        const data = await res.json();
        renderTable(data);
    } catch (error) {
        console.error("Error fetching transactions:", error);
        renderTable([]); // Render an empty table on error
    }
}

function renderTable(transactions) {
    const tbody = document.querySelector("#transactionsTable tbody");
    tbody.innerHTML = "";
    
    if (transactions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;">No records found</td></tr>';
        return;
    }
    
    transactions.forEach((t, i) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${i + 1}</td>
          <td>${t.book}</td>
          <td>${t.borrower}</td>
          <td>${t.issueDate}</td>
          <td>${t.dueDate}</td>
        `;
        tbody.appendChild(tr);
    });
}

fetchTransactions();