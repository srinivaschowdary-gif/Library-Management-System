// ✅ Form toggle functions (critical fix)
function showregister() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
}

function showlogin() {
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
}

// ✅ Main logic
window.onload = function() {
    document.getElementById("register-form").style.display = "none";

    const loginForm = document.querySelector('#login-form form');
    const registerForm = document.querySelector('#register-form form');
    const API_BASE = 'http://localhost:8080/api/auth';

    // 🔹 LOGIN EVENT
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.querySelector('#login-form input[name="email"]').value.trim();
        const password = document.querySelector('#login-form input[name="password"]').value;

        try {
            const res = await fetch(`${API_BASE}/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await res.json();

            if (res.ok && data.success) {
                alert(data.message + '\nWelcome ' + data.username);

                // Save user info locally
                localStorage.setItem('userId', data.id);
                localStorage.setItem('role', data.role);
                localStorage.setItem('username', data.username);
                localStorage.setItem('email', data.email);

                // Redirect based on role
                if (data.role === "Librarian") {
                    window.location.href = "managebook.html";
                } else {
                    window.location.href = "main.html";
                }
            } else {
                alert(data.message || 'Invalid email or password.');
            }
        } catch (err) {
            console.error('Login Fetch Error:', err);
            alert('Could not reach server. Please ensure your Java backend is running on port 8080.');
        }
    });

    // 🔹 REGISTER EVENT
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = document.querySelector('#reg-username').value.trim();
        const email = document.querySelector('#reg-email').value.trim();
        const password = document.querySelector('#reg-password').value;
        const role = document.getElementById('reg-role').value;

        if (!role) {
            alert('Please select a role (Student or Librarian) before registering.');
            return;
        }

        try {
            const res = await fetch(`${API_BASE}/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, email, password, role })
            });

            const data = await res.json();

            if (res.ok && data.success) {
                alert((data.message || 'Registered successfully!') + '\nYou can now login as ' + role + '.');
                showlogin(); // Go back to login form
            } else {
                alert(data.message || 'Registration failed. Please try again.');
            }
        } catch (err) {
            console.error('Registration Fetch Error:', err);
            alert('Could not reach server. Please ensure your Java backend is running on port 8080.');
        }
    });
};
