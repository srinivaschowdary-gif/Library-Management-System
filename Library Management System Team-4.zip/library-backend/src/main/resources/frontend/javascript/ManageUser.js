// 🛑 UPDATED API URL FOR LIBRARIAN MANAGEMENT 🛑
const baseURL = 'http://localhost:8080/api/users';


// --- Navigation Functions for Sidebar ---
function navigateTo(page) {
    if (page === 'managebooks') window.location.href = 'managebook.html';
    else if (page === 'manageusers') window.location.href = 'ManageUser.html';
    else if (page === 'transactions') window.location.href = 'transaction.html';
}

function logout() {
    alert("Logging out...");
    window.location.href = "login.html"; 
}
// ----------------------------------------

document.addEventListener('DOMContentLoaded', () => {
    const tbody = document.querySelector('#users-table tbody');
    const form = document.getElementById('user-form');
    const nameInput = document.getElementById('name');
    const roleInput = document.getElementById('role');
    const userIdInput = document.getElementById('user-id');
    const resetBtn = document.getElementById('reset-btn');

    async function loadUsers(){
        try {
            // Uses the new baseURL
            const res = await fetch(baseURL);
            const data = await res.json();
            tbody.innerHTML = '';
            data.forEach(u => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                  <td>${u.id}</td>
                  <td>${escapeHtml(u.name)}</td>
                  <td>${escapeHtml(u.role)}</td>
                  <td>
                    <button class="action-btn" data-id="${u.id}" data-action="edit">Edit</button>
                    <button class="action-btn remove" data-id="${u.id}" data-action="delete">Remove</button>
                  </td>`;
                tbody.appendChild(tr);
            });
        } catch (err) {
            console.error(err);
            tbody.innerHTML = '<tr><td colspan="4">Failed to load users</td></tr>';
        }
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = nameInput.value.trim();
        const role = roleInput.value;
        const id = userIdInput.value;

        if (!name) return alert('Enter name');

        try {
            if (id) {
                // update (Uses the new baseURL)
                const res = await fetch(`${baseURL}/${id}`, {
                  method:'PUT',
                  headers:{ 'Content-Type':'application/json' },
                  body: JSON.stringify({ name, role })
                });
                if (!res.ok) throw new Error('Update failed');
            } else {
                // create (Uses the new baseURL)
                const res = await fetch(baseURL, {
                  method:'POST',
                  headers:{ 'Content-Type':'application/json' },
                  body: JSON.stringify({ name, role })
                });
                if (!res.ok) throw new Error('Create failed');
            }
            resetForm();
            loadUsers();
        } catch (err) {
            console.error(err);
            alert('Error saving user');
        }
    });

    tbody.addEventListener('click', async (e) => {
        const btn = e.target.closest('button');
        if (!btn) return;
        const id = btn.dataset.id;
        const action = btn.dataset.action;
        if (action === 'edit') {
            // fetch single user then populate form (Uses the new baseURL)
            try {
                const res = await fetch(`${baseURL}/${id}`);
                const user = await res.json();
                userIdInput.value = user.id;
                nameInput.value = user.name;
                roleInput.value = user.role;
            } catch (err) { console.error(err); alert('Failed to fetch user'); }
        } else if (action === 'delete') {
            if (!confirm('Delete user?')) return;
            // delete (Uses the new baseURL)
            try {
                const res = await fetch(`${baseURL}/${id}`, { method:'DELETE' });
                if (!res.ok) throw new Error('Delete failed');
                loadUsers();
            } catch (err) { console.error(err); alert('Delete failed'); }
        }
    });

    resetBtn.addEventListener('click', resetForm);

    function resetForm(){
        userIdInput.value = '';
        nameInput.value = '';
        roleInput.value = 'Student';
    }

    function escapeHtml(s){
        return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    }

    // initial load
    loadUsers();
});